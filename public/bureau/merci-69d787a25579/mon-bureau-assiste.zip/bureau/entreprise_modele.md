# Fiche de l'entreprise

> Remplie avec l'utilisateur à l'installation. Les employés du bureau la lisent avant chaque tâche et la complètent quand il donne une nouvelle info.

## Identité
- Nom de l'entreprise :
- Nom du propriétaire :
- Ville / région :
- Adresse (pour les factures) :
- Téléphone, courriel, site web :
- NEQ (si applicable) :

## Ce que je vends
- Services ou produits, avec leurs prix :
- Mon client idéal :
- Ce qui me rend différent :

## Argent
- Inscrit aux taxes (TPS/TVQ) ? oui / non
- Numéros de TPS et de TVQ (si inscrit) :
- Dépôt demandé :
- Délai de paiement :
- Modes de paiement acceptés :

## Ma façon de communiquer
- Avec mes clients : tu / vous
- Ton : (chaleureux, direct, professionnel…)
- Mots ou expressions que j'utilise souvent :
- Réseaux sociaux utilisés :

## Objectifs
- Mon objectif principal cette année :
- Mon plus gros blocage :
