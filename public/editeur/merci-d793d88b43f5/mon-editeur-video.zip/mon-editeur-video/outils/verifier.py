"""Vérifie (et installe au besoin) tout ce qu'il faut — sans Terminal, sans mot de passe.

Usage : python3 verifier.py            (vérifie seulement)
        python3 verifier.py --installer (installe ce qui manque avec pip --user, puis revérifie)
"""
import importlib, os, platform, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))

PAQUETS = [("numpy", "numpy"), ("PIL", "pillow"), ("faster_whisper", "faster-whisper"), ("imageio_ffmpeg", "imageio-ffmpeg")]

def manquants():
    m = []
    for mod, pipname in PAQUETS:
        try:
            importlib.import_module(mod)
        except ImportError:
            m.append(pipname)
    return m

print("— Mon éditeur vidéo : vérification —")
print(f"Python {sys.version.split()[0]} ({platform.system()})")
if sys.version_info < (3, 9):
    print("✗ Python 3.9 ou plus est requis."); sys.exit(1)

m = manquants()
if m and "--installer" in sys.argv:
    print("Installation (sans mot de passe) : " + ", ".join(m))
    cmd = [sys.executable, "-m", "pip", "install", "--user", "--upgrade"] + m
    r = subprocess.run(cmd)
    if r.returncode != 0:  # Python « géré » (ex. Homebrew/Linux) : on réessaie avec l'option prévue
        subprocess.run(cmd + ["--break-system-packages"])
    importlib.invalidate_caches()
    import site
    try:
        sys.path.insert(0, site.getusersitepackages())
    except Exception:
        pass
    m = manquants()

for mod, pipname in PAQUETS:
    print(("✗ " if pipname in m else "✓ ") + pipname)

from commun import ffmpeg_bin
ff = ffmpeg_bin()
print(("✓ ffmpeg prêt : " + ff) if ff else "✗ ffmpeg complet introuvable")

ok = not m and ff is not None
if not ok and "--installer" not in sys.argv:
    print("\nIl manque des éléments → relance avec : python3 verifier.py --installer")
print("\nTOUT EST PRÊT ✓" if ok else "\nPas encore prêt.")
sys.exit(0 if ok else 1)
