# Bonus : 20 textes prêts à coller

Copie, remplace ce qui est entre [crochets], colle dans Claude.

## Sam — direction
1. Sam, mon rapport du matin.
2. Sam, fais-moi un plan sur 90 jours pour atteindre [objectif].
3. Sam, j'hésite entre [option A] et [option B]. Aide-moi à décider.
4. Sam, fais le bilan de ma semaine : [ce qui s'est passé].

## César — ventes
5. César, fais une soumission pour [client] : [service], [quantité], pour le [date].
6. César, écris le message qui accompagne cette soumission.
7. César, le client m'a répondu « [objection] ». Qu'est-ce que je lui réponds ?
8. César, quelles soumissions n'ont pas eu de réponse ? Prépare les suivis.

## Olivia — organisation
9. Olivia, voici tout ce que j'ai à faire cette semaine : [liste en vrac]. Organise-moi ça.
10. Olivia, trie mes courriels non lus et prépare les réponses urgentes.
11. Olivia, voici mes notes de réunion : [notes]. Fais le compte rendu et qui fait quoi.
12. Olivia, écris la procédure pas à pas pour [tâche que je répète souvent].

## Marcos — marketing
13. Marcos, fais mon calendrier de contenu pour le mois de [mois].
14. Marcos, écris une publication Facebook sur [sujet], avec 2 versions.
15. Marcos, écris le script d'une vidéo de 45 secondes sur [sujet].
16. Marcos, aide-moi à répondre à cet avis Google : [avis].

## Fiona — finances
17. Fiona, fais une facture pour [client] : [service] à [prix].
18. Fiona, quelles factures sont en retard ? Prépare les relances.

## Apollo — prospection
19. Apollo, trouve-moi 15 entreprises à [ville] qui pourraient avoir besoin de [mon service].
20. Apollo, écris un premier message personnalisé pour chaque entreprise de la liste.
