"""Coupe les pauses (et les mauvaises prises) + zooms aux coupes.

Usage :
  python3 couper.py VIDEO.mp4 --dossier DOSSIER [--retirer "12.4-15.1,40-41.2"] [--garder-pauses]
Produit : DOSSIER/travail/coupe.mp4 et DOSSIER/travail/coupe.json (correspondance des temps)
"""
import argparse, json, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from commun import run, probe, silences, lire_style, taille_format, ffmpeg_ok

ap = argparse.ArgumentParser()
ap.add_argument("video"); ap.add_argument("--dossier", required=True)
ap.add_argument("--retirer", default="", help="intervalles à enlever (mauvaises prises), en secondes de la vidéo originale")
ap.add_argument("--garder-pauses", action="store_true", help="ne coupe pas les silences (seulement --retirer)")
ap.add_argument("--debut", type=float, default=0); ap.add_argument("--fin", type=float, default=0)
a = ap.parse_args()
if not ffmpeg_ok(): sys.exit("ffmpeg manquant : lance verifier.py")

st = lire_style(a.dossier); info = probe(a.video)
FPS = 30; D = a.fin or info["duree"]; P = st["marge_coupe"]
out_dir = os.path.join(a.dossier, "travail"); os.makedirs(out_dir, exist_ok=True)

# 1) segments gardés = tout - silences - prises retirées
garde = [[a.debut, D]]
def soustraire(seg, x0, x1):
    r = []
    for s0, s1 in seg:
        if x1 <= s0 or x0 >= s1: r.append([s0, s1]); continue
        if x0 > s0: r.append([s0, x0])
        if x1 < s1: r.append([x1, s1])
    return r
if not a.garder_pauses:
    for s0, s1 in silences(a.video, None, st["pause_min"]):
        if s1 - s0 > 2 * P: garde = soustraire(garde, s0 + P, s1 - P)
for it in filter(None, a.retirer.split(",")):
    x0, x1 = map(float, it.split("-")); garde = soustraire(garde, x0, x1)
# aligner sur les images (évite le décalage son/image) et enlever les miettes
garde = [[round(s0 * FPS) / FPS, round(s1 * FPS) / FPS] for s0, s1 in garde]
garde = [g for g in garde if g[1] - g[0] >= 0.25]
if not garde: sys.exit("Rien à garder ?")

W, H = taille_format(st["format"], info["w"], info["h"])
Z = st["zooms"] if st["zoom_aux_coupes"] else [1.0]
liste, t_new, carte = [], 0.0, []
for i, (s0, s1) in enumerate(garde):
    n = round((s1 - s0) * FPS); z = Z[i % len(Z)]
    # recadrage au format puis zoom « punch-in »
    vf = (f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},"
          f"scale=iw*{z}:ih*{z},crop={W}:{H},setsar=1,fps={FPS}")
    seg = os.path.join(out_dir, f"seg_{i:03d}.mp4")
    run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-ss", f"{s0:.4f}", "-i", a.video,
         "-frames:v", str(n), "-vf", vf, "-af", f"atrim=0:{n/FPS:.5f},apad",
         "-t", f"{n/FPS:.5f}", "-c:v", "libx264", "-preset", "veryfast", "-crf", "14",
         "-pix_fmt", "yuv420p", "-c:a", "pcm_s16le", "-ar", "48000", "-ac", "2", seg.replace(".mp4", ".mov")])
    liste.append(f"file '{os.path.basename(seg).replace('.mp4', '.mov')}'")
    carte.append(dict(orig=[s0, s1], nouveau=[round(t_new, 3), round(t_new + n / FPS, 3)]))
    t_new += n / FPS
with open(os.path.join(out_dir, "liste.txt"), "w") as f: f.write("\n".join(liste))
coupe = os.path.join(out_dir, "coupe.mov")
run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i",
     os.path.join(out_dir, "liste.txt"), "-c", "copy", coupe])
for i in range(len(garde)):
    try: os.remove(os.path.join(out_dir, f"seg_{i:03d}.mov"))
    except OSError: pass
json.dump(dict(source=a.video, segments=carte, duree=round(t_new, 3)),
          open(os.path.join(out_dir, "coupe.json"), "w"), indent=1)
print(f"✓ Coupé : {info['duree']:.1f}s → {t_new:.1f}s  ({len(garde)} plans)  → {coupe}")
