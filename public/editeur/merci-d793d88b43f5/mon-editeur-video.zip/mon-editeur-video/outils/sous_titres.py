"""Sous-titres mot par mot + titres animés (fichier .ass).

Usage : python3 sous_titres.py --dossier DOSSIER [--titres titres.json]
Lit DOSSIER/travail/mots.json (+ titres.json optionnel) et le style.json.
Produit : DOSSIER/travail/sous_titres.ass

titres.json (écrit par Claude d'après la transcription) :
[ {"t": 1.2, "d": 2.5, "texte": "60 SECONDES", "accent": "pour tout comprendre", "pos": "haut"} ]
"""
import argparse, json, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from commun import lire_style, hex_ass, probe, taille_format

ap = argparse.ArgumentParser()
ap.add_argument("--dossier", required=True); ap.add_argument("--titres", default="")
a = ap.parse_args()
st = lire_style(a.dossier); tr = os.path.join(a.dossier, "travail")
mots = json.load(open(os.path.join(tr, "mots.json"), encoding="utf-8"))
vid = os.path.join(tr, "coupe.mov")
W, H = (1080, 1920)
if os.path.exists(vid):
    i = probe(vid); W, H = i["w"], i["h"]

def ts(t):
    t = max(0, t); h = int(t // 3600); m = int(t % 3600 // 60); s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"

C1, C2, CO = hex_ass(st["couleur_texte"]), hex_ass(st["couleur_mot"]), hex_ass(st["couleur_contour"])
CT, CA = hex_ass(st["couleur_titres"]), hex_ass(st["couleur_titres_accent"])
F, S = st["police"], st["taille_sous_titres"] * H // 1920
y = int(H * st["position_sous_titres"])
head = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {W}
PlayResY: {H}
WrapStyle: 2

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Sub,{F},{S},{C1},{C1},{CO},&H80000000,-1,0,0,0,100,100,0,0,1,{max(3, S//11)},{max(2, S//20)},5,60,60,0,1
Style: Titre,{F},{int(S*1.55)},{CT},{CT},{CO},&H80000000,-1,0,0,0,100,100,0,0,1,{max(4, S//9)},3,5,60,60,0,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
ev = []
# regrouper les mots en petites lignes : coupure sur la ponctuation, les pauses, ou N mots
groupes, g = [], []
for i, w in enumerate(mots):
    g.append(w)
    fin = (len(g) >= st["mots_par_ligne"] or w["mot"][-1:] in ".,!?;:" or
           (i + 1 < len(mots) and mots[i + 1]["t0"] - w["t1"] > 0.35))
    if fin: groupes.append(g); g = []
if g: groupes.append(g)
for gi, g in enumerate(groupes):
    fin_g = g[-1]["t1"] + 0.25
    if gi + 1 < len(groupes): fin_g = min(fin_g, groupes[gi + 1][0]["t0"])
    for k, w in enumerate(g):
        t0 = w["t0"]; t1 = g[k + 1]["t0"] if k + 1 < len(g) else fin_g
        parts = []
        for j, x in enumerate(g):
            txt = x["mot"].upper() if st["majuscules"] else x["mot"]
            parts.append(("{\\c" + C2 + "&\\fscx108\\fscy108}" + txt + "{\\c" + C1 + "&\\fscx100\\fscy100}") if j == k else txt)
        L = sum(len(x["mot"]) + 1 for x in g)
        fs = min(S, int(0.86 * W / (0.66 * max(6, L))))
        pop = "{\\fs%d\\pos(%d,%d)}" % (fs, W // 2, y)
        if k == 0:  # petit « pop » à l'apparition de la ligne
            pop = "{\\fs%d\\pos(%d,%d)\\fscx80\\fscy80\\t(0,120,\\fscx100\\fscy100)}" % (fs, W // 2, y)
        ev.append(f"Dialogue: 1,{ts(t0)},{ts(t1)},Sub,,0,0,0,,{pop}{' '.join(parts)}")

if a.titres and os.path.exists(a.titres):
    for ti in json.load(open(a.titres, encoding="utf-8")):
        ty = int(H * (0.16 if ti.get("pos", "haut") == "haut" else 0.45))
        txt = ti["texte"].upper()
        acc = ti.get("accent", "")
        fs = min(int(S * 2.1), int(0.9 * W / (0.6 * max(4, len(txt)))))
        anim = "{\\fs%d}" % fs + "{\\pos(%d,%d)\\fscx60\\fscy60\\alpha&HFF&\\t(0,180,\\fscx105\\fscy105\\alpha&H00&)\\t(180,260,\\fscx100\\fscy100)\\fad(0,150)}" % (W // 2, ty)
        line = anim + txt + ("\\N{\\c" + CA + "&\\fs" + str(int(S * 1.05)) + "}" + acc if acc else "")
        ev.append(f"Dialogue: 2,{ts(ti['t'])},{ts(ti['t'] + ti.get('d', 2.5))},Titre,,0,0,0,,{line}")

open(os.path.join(tr, "sous_titres.ass"), "w", encoding="utf-8").write(head + "\n".join(ev) + "\n")
print(f"✓ {len(groupes)} lignes de sous-titres → {os.path.join(tr, 'sous_titres.ass')}")
