"""Fonctions communes — Mon éditeur vidéo (Behn J. Productions)."""
import json, os, re, shutil, subprocess, sys

def _a_les_filtres(exe):
    try:
        out = subprocess.run([exe, "-hide_banner", "-filters"], capture_output=True, text=True, timeout=30).stdout
        return " subtitles " in out and " sidechaincompress " in out
    except Exception:
        return False

_FF = None
def ffmpeg_bin():
    """ffmpeg à utiliser : celui de l'ordinateur s'il est complet, sinon celui installé par pip
    (imageio-ffmpeg) — aucun Terminal ni mot de passe nécessaire."""
    global _FF
    if _FF: return _FF
    env = os.environ.get("MEV_FFMPEG")
    cands = [env] if env else []
    sysff = shutil.which("ffmpeg")
    if sysff: cands.append(sysff)
    try:
        import imageio_ffmpeg
        cands.append(imageio_ffmpeg.get_ffmpeg_exe())
    except Exception:
        pass
    for c in cands:
        if c and _a_les_filtres(c):
            _FF = c; return c
    return None

def ffmpeg_ok():
    return ffmpeg_bin() is not None

def run(cmd, **kw):
    """Lance une commande; affiche l'erreur clairement si elle échoue."""
    if cmd and cmd[0] == "ffmpeg": cmd = [ffmpeg_bin() or "ffmpeg"] + list(cmd[1:])
    r = subprocess.run(cmd, capture_output=True, text=True, **kw)
    if r.returncode != 0:
        sys.stderr.write("\n[ERREUR] " + " ".join(map(str, cmd))[:400] + "\n" + r.stderr[-2000:] + "\n")
        raise SystemExit(1)
    return r

def probe(path):
    """Durée, taille, images/s et présence de son — lus avec ffmpeg seul (pas besoin de ffprobe)."""
    r = subprocess.run([ffmpeg_bin() or "ffmpeg", "-hide_banner", "-nostdin", "-i", path], capture_output=True, text=True)
    e = r.stderr
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", e)
    duree = int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3)) if m else 0.0
    w = h = 0; fps = 30.0; rot = 0
    vm = re.search(r"Stream #.*Video:.*?(\d{2,5})x(\d{2,5})", e)
    if vm: w, h = int(vm.group(1)), int(vm.group(2))
    fm = re.search(r"([\d.]+) fps", e)
    if fm: fps = float(fm.group(1))
    rm = re.search(r"rotation of (-?[\d.]+) degrees", e) or re.search(r"rotate\s*:\s*(-?\d+)", e)
    if rm and abs(round(float(rm.group(1)))) % 180 == 90: w, h = h, w
    return dict(duree=duree, w=w, h=h, fps=fps, audio=" Audio:" in e)

def silences(path, seuil_db=None, min_s=0.45):
    """Silences [(debut, fin)] trouvés automatiquement selon le niveau réel de la voix
    (marche aussi avec un micro faible ou une pièce bruyante)."""
    import numpy as np
    raw = subprocess.run([ffmpeg_bin() or "ffmpeg", "-v", "error", "-nostdin", "-i", path, "-vn", "-ac", "1", "-ar", "16000",
                          "-f", "s16le", "-"], capture_output=True).stdout
    x = np.frombuffer(raw, np.int16).astype(np.float32) / 32768
    if len(x) < 1600: return []
    hop = 320  # 20 ms
    n = len(x) // hop
    rms = np.sqrt(np.mean(x[: n * hop].reshape(n, hop) ** 2, axis=1) + 1e-10)
    db = 20 * np.log10(rms)
    if seuil_db is None:
        bruit, voix = np.percentile(db, 10), np.percentile(db, 90)
        seuil_db = bruit + 0.35 * (voix - bruit)
    calme = db < seuil_db
    # lissage : un son isolé de moins de 60 ms ne casse pas un silence
    out, i0 = [], None
    for k, c in enumerate(np.append(calme, False)):
        if c and i0 is None: i0 = k
        elif not c and i0 is not None:
            if (k - i0) * hop / 16000 >= min_s: out.append((i0 * hop / 16000, k * hop / 16000))
            i0 = None
    fus = []
    for a, b in out:
        if fus and a - fus[-1][1] < 0.06: fus[-1] = (fus[-1][0], b)
        else: fus.append((a, b))
    return fus

def lire_style(dossier):
    """Charge style.json (dans le dossier de travail) avec des valeurs par défaut."""
    defaut = {
        "format": "vertical",          # vertical (1080x1920), carre (1080x1080), 45 (1080x1350), original
        "police": "Arial Black",
        "taille_sous_titres": 78,
        "couleur_texte": "#FFFFFF",
        "couleur_mot": "#FFB604",       # mot en cours (surbrillance)
        "couleur_contour": "#000000",
        "position_sous_titres": 0.72,   # 0 = haut, 1 = bas
        "mots_par_ligne": 3,
        "majuscules": True,
        "zoom_aux_coupes": True,
        "zooms": [1.0, 1.12, 1.05, 1.18],
        "couleur_titres": "#FFFFFF",
        "couleur_titres_accent": "#9F1204",
        "volume_musique": 0.22,
        "queue_musique": 1.5,           # secondes de musique après la dernière phrase
        "pause_min": 0.45,              # silence minimum coupé (s)
        "marge_coupe": 0.08             # on garde un peu d'air autour des mots (s)
    }
    p = os.path.join(dossier, "style.json")
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            defaut.update(json.load(f))
    return defaut

def taille_format(fmt, w, h):
    return {"vertical": (1080, 1920), "carre": (1080, 1080), "45": (1080, 1350)}.get(fmt, (w - w % 2, h - h % 2))

def hex_ass(h, alpha="00"):
    h = h.lstrip("#")
    return f"&H{alpha}{h[4:6]}{h[2:4]}{h[0:2]}".upper()
