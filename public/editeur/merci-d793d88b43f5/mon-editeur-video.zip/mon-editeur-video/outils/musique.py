"""Incruste les sous-titres et mixe la voix avec la musique (la musique baisse quand tu parles).

Usage : python3 musique.py --dossier DOSSIER --sortie FINAL.mp4 [--musique MUSIQUE.mp3] [--debut-musique 0]
Lit DOSSIER/travail/coupe.mov et DOSSIER/travail/sous_titres.ass (si présent).
"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from commun import run, probe, lire_style

ap = argparse.ArgumentParser()
ap.add_argument("--dossier", required=True); ap.add_argument("--sortie", required=True)
ap.add_argument("--musique", default=""); ap.add_argument("--debut-musique", type=float, default=0)
ap.add_argument("--sans-sous-titres", action="store_true")
a = ap.parse_args()
st = lire_style(a.dossier); tr = os.path.join(a.dossier, "travail")
vid = os.path.join(tr, "coupe.mov"); ass = os.path.join(tr, "sous_titres.ass")
d = probe(vid)["duree"]; Q = st["queue_musique"]; tot = d + (Q if a.musique else 0)

vf = f"tpad=stop_mode=clone:stop_duration={Q if a.musique else 0}"
if os.path.exists(ass) and not a.sans_sous_titres:
    # chemin échappé pour le filtre subtitles (Windows et Mac)
    p = os.path.abspath(ass).replace("\\", "/").replace(":", "\\:").replace("'", "\\'")
    vf += f",subtitles='{p}'"
cmd = ["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", vid]
if a.musique:
    cmd += ["-ss", str(a.debut_musique), "-i", a.musique]
    fc = (f"[0:a]loudnorm=I=-15:TP=-1.5:LRA=11,apad=whole_dur={tot},asplit=2[v][k];"
          f"[1:a]aresample=48000,atrim=0:{tot},asetpts=PTS-STARTPTS,volume={st['volume_musique']},"
          f"afade=t=in:d=0.5,afade=t=out:st={max(0, tot-1.6)}:d=1.6[m];"
          f"[m][k]sidechaincompress=threshold=0.03:ratio=6:attack=20:release=400[md];"
          f"[v][md]amix=inputs=2:normalize=0:duration=first,alimiter=limit=0.95,atrim=0:{tot}[a]")
    cmd += ["-filter_complex", f"[0:v]{vf}[vv];{fc}", "-map", "[vv]", "-map", "[a]"]
else:
    cmd += ["-vf", vf, "-af", "loudnorm=I=-15:TP=-1.5:LRA=11"]
cmd += ["-c:v", "libx264", "-preset", "medium", "-crf", "17", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", a.sortie]
run(cmd)
print(f"✓ Vidéo finale : {a.sortie}  ({tot:.1f}s)")
