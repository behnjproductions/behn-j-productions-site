# Bonus : 15 textes prêts à coller

Copie un texte, remplace ce qui est entre [crochets], colle-le dans Claude. C'est tout.

## Monter
1. Monte [ma-video.mp4] : coupe les pauses, garde la dernière prise quand je recommence une phrase, et mets ma musique.
2. Monte [ma-video.mp4] en version Reels verticale, avec des sous-titres mot par mot et 3 titres animés sur mes phrases fortes.
3. Fais une version 4:5 pour le fil Facebook de [ma-video.mp4], avec les sous-titres bien au centre.
4. Fais une version carrée de mon dernier montage pour Instagram.
5. Monte toutes les vidéos du dossier [nom-du-dossier], une par une, avec mon style habituel.

## Titres et sous-titres
6. Ajoute un titre accrocheur dans les 2 premières secondes, en 3 ou 4 mots maximum.
7. Mets les sous-titres plus haut et un peu plus gros.
8. Change la couleur du mot qui s'allume pour [#couleur ou nom de couleur].
9. Écris les sous-titres en majuscules.
10. Corrige l'orthographe des sous-titres : [mot mal écrit] doit s'écrire [bon mot].

## Musique et son
11. Mets la musique un peu plus fort, mais garde ma voix bien claire.
12. Utilise [musique.mp3] et commence la musique à [30] secondes du morceau.
13. Laisse la musique continuer 2 secondes après mon dernier mot.

## Coupes et rythme
14. C'est trop haché : garde un peu plus de pauses et refais le montage.
15. Remets la phrase où je parle de [sujet], tu l'as coupée.

## Astuce
Tu peux tout combiner dans une seule phrase : « Monte ma-video.mp4 en 4:5, musique plus forte, et un titre au début. »
