"""Transcription mot par mot (avec le temps de chaque mot).

Usage : python3 transcrire.py VIDEO --dossier DOSSIER [--langue fr] [--modele small]
Produit : DOSSIER/travail/mots.json  et  DOSSIER/travail/transcription.txt (lisible, avec les temps)
Le premier lancement télécharge le modèle de reconnaissance vocale (une seule fois).
"""
import argparse, json, os, sys
ap = argparse.ArgumentParser()
ap.add_argument("video"); ap.add_argument("--dossier", required=True)
ap.add_argument("--langue", default="fr"); ap.add_argument("--modele", default="small")
ap.add_argument("--sortie", default="mots.json")
a = ap.parse_args()
try:
    from faster_whisper import WhisperModel
except ImportError:
    sys.exit("faster-whisper manquant : python3 -m pip install --user faster-whisper")

out = os.path.join(a.dossier, "travail"); os.makedirs(out, exist_ok=True)
print("Transcription en cours… (le premier essai télécharge le modèle)")
m = WhisperModel(a.modele, device="auto", compute_type="int8")
segs, _ = m.transcribe(a.video, language=a.langue, word_timestamps=True, vad_filter=True)
mots, lignes = [], []
for s in segs:
    lignes.append(f"[{s.start:6.2f} → {s.end:6.2f}] {s.text.strip()}")
    for w in (s.words or []):
        t = w.word.strip()
        if t: mots.append(dict(t0=round(w.start, 3), t1=round(w.end, 3), mot=t))
json.dump(mots, open(os.path.join(out, a.sortie), "w", encoding="utf-8"), ensure_ascii=False, indent=0)
open(os.path.join(out, a.sortie.replace(".json", ".txt").replace("mots", "transcription")), "w", encoding="utf-8").write("\n".join(lignes))
print(f"✓ {len(mots)} mots → {os.path.join(out, a.sortie)}")
print("\n".join(lignes))
