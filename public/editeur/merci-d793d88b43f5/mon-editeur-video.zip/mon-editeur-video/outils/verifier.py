"""Vérifie que tout est installé. Usage : python3 verifier.py"""
import importlib, platform, shutil, subprocess, sys

ok = True
print("— Mon éditeur vidéo : vérification —")
print(f"Python {sys.version.split()[0]} ({platform.system()})")
if sys.version_info < (3, 9):
    print("✗ Python 3.9 ou plus est requis."); ok = False

if shutil.which("ffmpeg"):
    out = subprocess.run(["ffmpeg", "-hide_banner", "-filters"], capture_output=True, text=True).stdout
    print("✓ ffmpeg trouvé" + ("" if " subtitles " in out else "  (⚠ sans libass : les sous-titres ne pourront pas être incrustés)"))
else:
    ok = False
    sysname = platform.system()
    print("✗ ffmpeg manquant. Pour l'installer :")
    if sysname == "Darwin":
        print("   brew install ffmpeg      (si brew manque : https://brew.sh)")
    elif sysname == "Windows":
        print("   winget install Gyan.FFmpeg")
    else:
        print("   sudo apt install ffmpeg")

manquants = []
for mod, pipname in [("numpy", "numpy"), ("PIL", "pillow"), ("faster_whisper", "faster-whisper")]:
    try:
        importlib.import_module(mod); print(f"✓ {pipname}")
    except ImportError:
        manquants.append(pipname); print(f"✗ {pipname} manquant")
if manquants:
    ok = False
    print("   Installer avec :  python3 -m pip install --user " + " ".join(manquants))

print("\nTOUT EST PRÊT ✓" if ok else "\nIl manque des éléments (voir ci-dessus).")
sys.exit(0 if ok else 1)
