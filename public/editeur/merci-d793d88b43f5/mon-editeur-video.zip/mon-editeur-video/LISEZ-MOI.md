# Mon éditeur vidéo — Guide d'installation

Merci pour ton achat ! Il te faut environ 10 minutes pour tout installer, une seule fois.

## Ce qu'il te faut

- Un ordinateur Mac ou Windows.
- L'application **Claude** pour ordinateur (pas le site dans le navigateur), avec un abonnement qui permet de travailler dans un dossier en mode **Local**.

## Installation

1. Crée un dossier pour tes vidéos, par exemple `Mes vidéos`.
2. Mets dedans le fichier **mon-editeur-video.zip** (tu n'as pas besoin de le décompresser).
3. Ouvre l'application Claude et commence une **nouvelle conversation**. Choisis **Local**, puis sélectionne ton dossier `Mes vidéos`.
4. Copie-colle ce message :

> Installe le fichier mon-editeur-video.zip qui est dans ce dossier : décompresse-le dans mon dossier de compétences (~/.claude/skills/mon-editeur-video), puis lance la vérification et installe ce qui manque.

5. Claude te demandera la permission d'installer ffmpeg et les modules Python. Accepte : il ne le fait qu'une fois.

À la fin, il doit écrire **« TOUT EST PRÊT ✓ »**.

## Apprendre ton style

1. Mets 3 à 5 vidéos dont tu aimes le style dans le sous-dossier `references`.
2. Mets tes musiques libres de droits dans le sous-dossier `musique`.
3. Écris à Claude :

> Analyse mes vidéos de référence et crée mon style. Mes couleurs sont #9F1204 et #FFB604.

(Remplace par tes propres couleurs.)

## Monter une vidéo

1. Mets ta vidéo dans ton dossier.
2. Écris à Claude, par exemple :

> Monte ma-video.mp4 : coupe les pauses et garde la dernière prise, ajoute les sous-titres et la musique.

Ta vidéo finie arrive dans le dossier `montages`.

Pour réviser, parle-lui normalement :
- « La musique un peu plus fort. »
- « Les sous-titres plus haut. »
- « Moins de zoom. »
- « Garde la phrase sur mes clients. »

## Bon à savoir

- Tes vidéos originales ne sont jamais modifiées.
- La première transcription télécharge le modèle de reconnaissance vocale. Ça prend quelques minutes, une seule fois.
- Une question ? Écris-moi : behnjproductions.ca/contact

Behn J. Productions · behnjproductions.ca
