"""Analyse 3 à 5 vidéos de référence pour trouver le style (rythme, couleurs, cadrage).

Usage : python3 style.py --dossier DOSSIER   (lit DOSSIER/references/*)
Produit : DOSSIER/travail/style_rapport.json  +  une planche d'images par vidéo (à regarder)
"""
import argparse, glob, json, os, re, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from commun import probe, run

ap = argparse.ArgumentParser(); ap.add_argument("--dossier", required=True)
a = ap.parse_args()
refs = sorted(sum([glob.glob(os.path.join(a.dossier, "references", e)) for e in ("*.mp4", "*.mov", "*.MP4", "*.MOV", "*.m4v", "*.webm")], []))
if not refs: sys.exit("Mets 3 à 5 vidéos dans le dossier « references ».")
tr = os.path.join(a.dossier, "travail"); os.makedirs(tr, exist_ok=True)
rap = []
for i, r in enumerate(refs):
    info = probe(r)
    out = subprocess.run(["ffmpeg", "-hide_banner", "-nostdin", "-i", r, "-vf",
                          "scale=320:-2,select='gt(scene,0.32)',showinfo", "-an", "-f", "null", "-"],
                         capture_output=True, text=True).stderr
    coupes = len(re.findall(r"pts_time:", out))
    planche = os.path.join(tr, f"planche_ref{i+1}.jpg")
    n = 12; fr = max(0.2, n / max(1, info["duree"]))
    run(["ffmpeg", "-nostdin", "-y", "-v", "error", "-i", r, "-vf",
         f"fps={fr:.4f},scale=240:-2,tile=6x2", "-frames:v", "1", planche])
    couleurs = []
    try:
        from PIL import Image
        im = Image.open(planche).convert("RGB").quantize(6).convert("RGB")
        couleurs = ["#%02X%02X%02X" % c for _, c in sorted(im.getcolors(64), reverse=True)[:6]]
    except Exception:
        pass
    rap.append(dict(fichier=os.path.basename(r), duree=round(info["duree"], 1),
                    format=f"{info['w']}x{info['h']}", plans=coupes + 1,
                    secondes_par_plan=round(info["duree"] / (coupes + 1), 2),
                    couleurs_dominantes=couleurs, planche=planche))
json.dump(rap, open(os.path.join(tr, "style_rapport.json"), "w"), indent=1, ensure_ascii=False)
for x in rap:
    print(f"• {x['fichier']}: {x['duree']}s, {x['plans']} plans (~{x['secondes_par_plan']}s/plan), couleurs {', '.join(x['couleurs_dominantes'])}")
print("\nRegarde les planches pour voir les sous-titres, les titres et le cadrage, puis écris style.json.")
